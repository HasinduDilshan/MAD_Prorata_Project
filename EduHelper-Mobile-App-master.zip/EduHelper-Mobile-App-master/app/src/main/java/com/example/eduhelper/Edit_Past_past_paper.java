package com.example.eduhelper;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Edit_Past_past_paper extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit__past_past_paper);
    }
}
