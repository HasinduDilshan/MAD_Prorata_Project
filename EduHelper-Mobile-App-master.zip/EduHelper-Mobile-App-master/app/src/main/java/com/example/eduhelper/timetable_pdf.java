package com.example.eduhelper;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class timetable_pdf extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable_pdf);
    }
}
